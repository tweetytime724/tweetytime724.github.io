// Advising Assistance Program.cpp : This file contains the 'main' function. Program execution begins and ends there.
// by Samantha Lasseigne

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

// create an unique Identifier
struct Course {
    string courseID;
    string name;
    string preReq;
    Course() {
        courseID = "none";
    }
};

// create a structure for the tree nodes
struct Node {
    Course course;
    Node* left;
    Node* right;

    // default constructor
    Node() {
        left = nullptr;
        right = nullptr;
    }
    // intializing with a course
    Node(Course someCourse) : Node() {
        course = someCourse;
    }
};

// classe creation
class AdvisingAssistanceProgram {

private: // private class attributes for the tree
    Node* root;

    void addNode(Node* node, Course course);
    void inOrder(Node* node);

public: // public methods for the main() to use.
    AdvisingAssistanceProgram();
    void ReadFile(string);
    void SliceAndVector(vector<string>);
    void BinaryTreeAdd(Course course);
    void BinaryTreePrintCourses();
    void BinaryTreePrintCourse(string);
};

void AdvisingAssistanceProgram::addNode(Node* node, Course course)
{
    // if the node is bigger than the course we are adding move to the left child node
    if (node->course.courseID.compare(course.courseID) > 0) {
        // check left for null node to add new course
        if (node->left == nullptr) {
            node->left = new Node(course);
        }
        else {
            // check node on left for another empty leaf node.
            addNode(node->left, course);
        }
    }
    // else move to the right child node to add new node
    else {
        if (node->right == nullptr) {
            node->right = new Node(course);
        }
        else {
            // if right node is not vacant, run through the method again for a right child that is null
            addNode(node->right, course);
        }
    }
}

void AdvisingAssistanceProgram::inOrder(Node* node)
{
    Course course;
    if (node != nullptr) { // if node is not empty
        inOrder(node->left); // move to the left most child leaf
        cout << course.courseID << ", " << course.name << endl; // display course information
        inOrder(node->right); // check right child 
    }
}

// constructor
AdvisingAssistanceProgram::AdvisingAssistanceProgram()
{
    root = nullptr; // root starts empty
}

void AdvisingAssistanceProgram::ReadFile(string fileInput)
{
    fstream inFS;
    vector<string> fileCopyList;
    string fileString;

    inFS.open(fileInput);
    if (!inFS.is_open()) {  // check if file is open, if not display statement
        cout << "Could not open file" << endl;
    }
    while (!inFS.fail()) {  // while there is still information in the file
        inFS >> fileString; // input string of file 
        if (fileString.size() >= 0) { // save file string to a vector for later use.
            fileCopyList.push_back(fileString);
        }
    }
    inFS.close(); //closes the file.

    if (fileCopyList.size() == 0) { // if the vector size is zero, display statement.
        cout << "File was empty" << endl;
    }
    SliceAndVector(fileCopyList); // call new method
}

void AdvisingAssistanceProgram::SliceAndVector(vector<string> fileCopyList)
{
    Course course;
    string temp;
    for (int i = 0; i < fileCopyList.size(); i++) { // for each item in the vector...
        temp = fileCopyList[i]; // add string to a temporary string
        course.courseID = temp.substr(0, ','); // split string from beginning to first comma and assign to courseID
        course.name = temp.substr(',', temp.size() - 1); // assign the remainder to course name
        if (course.name.find(',')) { // if another comma is in course name
            temp = course.name; // assign name to temp
            course.name = temp.substr(0, ','); // reassign name from beginning of temp to the comma
            course.preReq = temp.substr(',', temp.size() - 1); // assign preReq from the comma to the end of temp.
        }
        else { // otherwise preReq is null
            course.preReq = nullptr;
        }
        BinaryTreeAdd(course);
    }
}

void AdvisingAssistanceProgram::BinaryTreeAdd(Course course)
{
    // if the root is null, the course becomes the root
    if (root == nullptr) {
        root = new Node(course);
    }
    else {
        // calls the private method where the root is stored
        addNode(root, course);
    }
}

void AdvisingAssistanceProgram::BinaryTreePrintCourses()
{
    // calls for the private methods to do the work
    inOrder(root);
}

void AdvisingAssistanceProgram::BinaryTreePrintCourse(string input)
{
    Node* current = root;
    Course course;

    while (current != nullptr) { // while current is not null
        if (input == current->course.courseID) { // if input equals the correct node, display course information
            cout << current->course.courseID << ", " << current->course.name <<
                "Prerequisites: " << current->course.preReq << endl;
        }
        else if (input < current->course.courseID) { // if the input is less than the current node course ID, check left child
            current = current->left;
        }
        else { // if input is greater, check right child.
            current = current->right;
        }
    }
    return;
}

int main()
{
    AdvisingAssistanceProgram* aap = new AdvisingAssistanceProgram();
    Course course;
    // attrubutes for main()
    int choice = 0; // intializes the integer input to zero for the while loop.
    string fileInput;

    

    // while loop to continuously display menu until
    while (choice != 9) {
        // Welcomes user and displays the menu options
        cout << "Welcome to the course planner" << endl;
        cout << endl;

        cout << "1. Load Data Structure." << endl;
        cout << "2. Print Course List." << endl;
        cout << "3. Print Course." << endl;
        cout << "9. Exit" << endl << endl;
        cout << "What would you like to do?" << endl;


        cin >> choice;
        switch (choice) {

        case 1:
            cout << "What file would you like to load?" << endl << endl;
            cin >> fileInput;
            aap->ReadFile(fileInput);
            break;

        case 2:
            aap->BinaryTreePrintCourses();
            break;

        case 3:
            cout << "What is the course ID you want to know more about?" << endl;
            break;

        default:
            cout << choice << " is not a valid option." << endl << endl;
            break;
        }
    }
    cout << "Thank you for using the course planner!" << endl;
}