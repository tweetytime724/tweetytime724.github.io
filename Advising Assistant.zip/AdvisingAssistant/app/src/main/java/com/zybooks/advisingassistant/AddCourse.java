package com.zybooks.advisingassistant;

import static android.view.View.VISIBLE;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class AddCourse extends AppCompatActivity {

    BinaryTreeClass binaryTreeclass = new BinaryTreeClass();
    CourseDatabase courseDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_course);

        TextView error = findViewById(R.id.errorsDisplay);

        // This button returns from current page to MainActivity class
        Button backButton = findViewById(R.id.back);
        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(AddCourse.this.getBaseContext(), MainActivity.class);
            AddCourse.this.startActivity(intent);
        });

        // variables for taking in the course information that was entered.
        EditText addId = findViewById(R.id.addCourseID);
        EditText addName = findViewById(R.id.addCourseName);
        EditText addPreReq = findViewById(R.id.addPreReq);

        /* This button will create variables for the 3 input text. If there is a null variable it will
        * spit out an error in the edit text box at the bottom of the page.
        *
        * It will store the data in a temporary object to be added to the tree. It will then clear
        * the lines for another course to be added.  */
        @NonNull
        Button addID = findViewById(R.id.addCourseButton);
        addID.setOnClickListener(v -> {
            Course course = new Course();

            String id = addId.getText().toString();
            String name = addName.getText().toString();
            String req = addPreReq.getText().toString();

            course.set_courseId(id);
            course.set_name(name);
            course.set_preReq(req);

            if (course != null) {
                /* This will enter the added course into both the binary tree and the course database.*/
                binaryTreeclass.addToTree(course);
                CourseDatabase courseDatabase = new CourseDatabase(AddCourse.this);
                courseDatabase.add(course);

                Toast.makeText(this, "Course Added", Toast.LENGTH_SHORT).show();
                addId.setText("");
                addName.setText("");
                addPreReq.setText("");
            }
            else {
                error.setVisibility(VISIBLE);
            }

        });
    }
    protected void onPause(){
        super.onPause();
    }
    protected void onResume() {
        super.onResume();
    }

}
