package com.zybooks.advisingassistant;

import static android.view.View.INVISIBLE;
import static android.view.View.VISIBLE;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.security.NoSuchAlgorithmException;

import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

public class LoginPage extends AppCompatActivity {

    ConcurrentHashMap<String, byte[] > credentials = new ConcurrentHashMap<>();
    HashingHere hashingHere = new HashingHere();
    Users user = new Users(LoginPage.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.login_page);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        EditText username = findViewById(R.id.usernameInput);
        EditText password = findViewById(R.id.passwordInput);
        EditText newUser = findViewById(R.id.newUserName);
        EditText newPassword= findViewById(R.id.newPassword);
        Button newUserClick = findViewById(R.id.newUserButton);
        Button submit = findViewById(R.id.SignIn);
        Button createUser = findViewById(R.id.createUser);
        Button returnToLogin = findViewById(R.id.returnToSignIn);

        /* Submit button actions
        *
        * this verifies the name and password match what is on record. */
        submit.setOnClickListener(v -> {
            String userInput = username.getText().toString();
            String passwordInput = password.getText().toString();
            Log.d("password", "password enter" + passwordInput);

            try {

                if (!user.verifyUsername(userInput)) {
                    Toast.makeText(this, "Username not valid, please try again", Toast.LENGTH_LONG).show();
                    username.setText("");
                    password.setText("");
                    return;
                }

                if (verifyPassword(userInput, passwordInput)) {
                    Toast.makeText(this, "welcome", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(LoginPage.this.getBaseContext(), MainActivity.class);
                    LoginPage.this.startActivity(intent);
                }
                else {
                    Toast.makeText(this, "Error: Username does not exists", Toast.LENGTH_SHORT).show();
                    username.setText("");
                    password.setText("");
                }
            } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
                throw new RuntimeException(e);
            }

        });

        /* This button will switch everything from viewing the sign in components to new user components*/
        newUserClick.setOnClickListener(view -> {
            username.setVisibility(INVISIBLE);
            password.setVisibility(INVISIBLE);
            submit.setVisibility(INVISIBLE);
            newUser.setVisibility(VISIBLE);
            newPassword.setVisibility(VISIBLE);
            createUser.setVisibility(VISIBLE);
            newUserClick.setVisibility(INVISIBLE);
            returnToLogin.setVisibility(VISIBLE);
        });

        /* This button will switch everything from the new user components to the sign in components*/
        returnToLogin.setOnClickListener(view -> {
            username.setVisibility(VISIBLE);
            password.setVisibility(VISIBLE);
            submit.setVisibility(VISIBLE);
            newUser.setVisibility(INVISIBLE);
            newPassword.setVisibility(INVISIBLE);
            createUser.setVisibility(INVISIBLE);
            newUserClick.setVisibility(VISIBLE);
            returnToLogin.setVisibility(INVISIBLE);
        });

        /* Create New User button
        *
        * This creates the username and password to enter into the map storage. */
        createUser.setOnClickListener(view -> {
            String newUsername = newUser.getText().toString();
            String newPasscode = newPassword.getText().toString();

            /*if(user.verifyUsername(newUsername)) {
                Toast.makeText(this, "Sorry, User already exists. Try something unique.", Toast.LENGTH_SHORT).show();
                newUser.setText("");
                newUser.setText("");
            }*/
            try {
                addUser(newUsername, newPasscode);
            } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
                throw new RuntimeException(e);
            }
            newUser.setText("");
            newPassword.setText("");
        });
    }

    /* This addUser method calls the Hashing Here class to hash the password. It returns the hashed password and the
    * salt to be saved. It will call on the concurrent hash map to store the hashed password as the key and the salt as the
    * value. It will also call the Users database to save the username and hashed password.
    *
    * I tried to save the salt in the database, however when I query the salt it changes it's value. */
    public void addUser(String username, String password) throws NoSuchAlgorithmException, InvalidKeySpecException {
        ArrayList<HashClass> hashInfo = HashingHere.hashPassword(username, password);

        Log.d("addUser", "method entered");
        for (int i = 0; i < hashInfo.size(); i++) {
            if (hashInfo.get(i).get_username().compareTo(username) == 0) {
                String hashPass = hashInfo.get(i).get_hashed();
                byte[] savedSalt = hashInfo.get(i).get_salt();
                Log.d("addUser method", username + " " + hashPass + " " + savedSalt);
                credentials.put(hashPass, savedSalt);
                Log.d("adduser", "salt "+ credentials.get(hashPass));
                user.add(username, hashPass);
            }
        }
        Toast.makeText(this, "username and password accepted", Toast.LENGTH_SHORT).show();
    }

    /* This verify Password method will call the Users database to retrieve the saved hashed password.
    * It will also call the hashmap for the salt. Finally it it will call the Hashing here class to
    * hash the inputted password from the user to hash it with the salt that was used before so we can
    * see if both hashed passwords match. */
    public boolean verifyPassword(String username, String password) throws NoSuchAlgorithmException, InvalidKeySpecException {
        Log.d("Login verifyPassword", "verified password");

        String storedHashPassword = user.getStoredPassword(username);
        Log.d("check hashedpassword", storedHashPassword);
        byte[] storedSalt = credentials.get(storedHashPassword);
        Log.d("check stored salt", storedSalt + " is retrieved");
        String hashed = HashingHere.verifyPassword(password, storedSalt);

        Log.d("Login verifyPassword", "StoredHash " + storedHashPassword +"  salt "
                + storedSalt + "   newHashed " + hashed);

        if (storedHashPassword.compareTo(hashed) == 0) {
            return true;
        }

        return false;
    }
}
