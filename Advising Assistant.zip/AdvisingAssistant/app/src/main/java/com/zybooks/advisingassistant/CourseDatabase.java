package com.zybooks.advisingassistant;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class CourseDatabase extends SQLiteOpenHelper {

    /* The database will be created here and methods will also be called here. The CourseTable class creates
    * all the attributes that will be used to create the table as well for any get-method we could use.*/

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "courses.db";

    public CourseDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    static final class CourseTable {
        static final String TABLE = "courseList";
        static final String COURSEID = "courseID";
        static final String NAME = "name";
        static final String PREREQ = "preReq";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = ("CREATE TABLE " + CourseTable.TABLE + "(" + CourseTable.COURSEID + " TEXT PRIMARY KEY ,"
                + CourseTable.NAME + " TEXT," + CourseTable.PREREQ + " TEXT ) ");
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS courseList");
        onCreate(db);
    }
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }

    /* The add method will add each part of the course class to the table by the insert command. */
    public void add(Course course) {

        Log.d("check method", "method entered");
        SQLiteDatabase db = this.getWritableDatabase();
        Log.d("database opened", "database opened");

        ContentValues values = new ContentValues();
        values.put(CourseTable.COURSEID, course.getCourseId());
        values.put(CourseTable.NAME, course.getName());
        values.put(CourseTable.PREREQ, course.get_preReq());

        Long result = db.insert(CourseTable.TABLE, null, values);
        db.close();

        Log.d("db", "db added");
    }
    /* This is the more basic getList method, this will only call all courses that are added to the
    * database. */
    public ArrayList < Course > getList() {
        ArrayList< Course > courses = new ArrayList<>();

        String selectQuery = "SELECT * FROM courseList";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Course course = new Course();
                course.parse(cursor);
                courses.add(course);
            } while (cursor.moveToNext());
        }
        db.close();
        return courses;
    }

    /* This method will call the database to get a single course. The query will call all Course ID's that
    * are contained with the course Id requested. It will then save the data into an array to transfer
    * back to the ListSingleCourse.java to be displayed. */
    public ArrayList < Course > getSingleCourse(String id) {
        ArrayList < Course > course = new ArrayList<>();
        Course courses = new Course();
        String selectQuery = " SELECT * FROM " + CourseTable.TABLE + " WHERE " + CourseTable.COURSEID + " = ? ";
        String[] selectionArgs = { String.valueOf(id)};

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor =  db.rawQuery(selectQuery, selectionArgs);

        if (cursor.moveToFirst()) {
            int colIndexID = cursor.getColumnIndex(CourseTable.COURSEID);
            int colIndexName = cursor.getColumnIndex(CourseTable.NAME);
            int colIndexPreReq = cursor.getColumnIndex(CourseTable.PREREQ);

            if (colIndexID != -1) {

                String idC = cursor.getString(colIndexID);
                String name = cursor.getString(colIndexName);
                String req = cursor.getString(colIndexPreReq);

                courses.set_courseId(idC);
                courses.set_name(name);
                courses.set_preReq(req);

                course.add(courses);
            }
        }
        cursor.close();
        db.close();

        return course;
    }
}
