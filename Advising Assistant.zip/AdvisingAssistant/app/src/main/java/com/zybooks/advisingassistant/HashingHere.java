package com.zybooks.advisingassistant;

/* For this security measure of hashing a password to keep information safe I am using PBKDF2 -
 * Password-Based key derivation function 2. My main plan was to use BCrypt but it is not fully
 * in Java yet and SHA-512, which I used before is not recommended due to vulnerabilities.*/

import android.util.Log;

import java.math.BigInteger;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.ArrayList;


import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class HashingHere {

    static HashClass hashClass = new HashClass();
    static ArrayList< HashClass > hashInfo = new ArrayList<>();


    /* The hashPassword method will take a password string that the user inputs and make it more difficult to hack.
    *
    * By randomizing the salt (random characters mixed with the password to make it 16 characters long) then passing through the
    * hashing process of changing characters based on the factory string, the number of times to go through the string(iterationCount) and
    * picking a key.*/

    public static ArrayList < HashClass> hashPassword(String username, String password) throws NoSuchAlgorithmException, InvalidKeySpecException {
        Log.d("hashPassword", "entered hashPassword");
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[16];
        random.nextBytes(salt);

        KeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 65536, 128);
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");

        byte[] hash = factory.generateSecret(spec).getEncoded();
        String hashedPassword = String.format("%x", new BigInteger(hash));
        Log.d("hashed", "password hashed" + hashedPassword);

        hashClass.set_username(username);
        hashClass.set_salt(salt);
        hashClass.set_hashed(hashedPassword);

        hashInfo.add(hashClass);
        return hashInfo;
    }

    /* The verifyPassword method will take the password the user provided, obtain the saved salt and saved hashedPassword for verification.
    *
    * It will then run the password provided with the saved salt to obtain the correct hash and verify it was the correct password.*/
    public static String verifyPassword(String password, byte[] savedSalt) throws NoSuchAlgorithmException, InvalidKeySpecException {

        Log.d("verifyPassword in HashingHere", "entered HH verify savedSalt: " + savedSalt +" salt ");


        KeySpec spec = new PBEKeySpec(password.toCharArray(), savedSalt, 65536, 128);
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");

        byte[] hash = factory.generateSecret(spec).getEncoded();
        String hashedPassword = String.format("%x", new BigInteger(hash));
        Log.d("verify hash", "hashed password " + hashedPassword);

        return hashedPassword;
    }
}
