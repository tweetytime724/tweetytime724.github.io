package com.zybooks.advisingassistant;

/* This HashClass makes it easier to pull the information I need to verify the password in an array */
public class HashClass {
    String _username;
    byte [] _salt;
    String _hashed;

    public void set_username(String username) {
        _username = username;
    }
    public void set_salt(byte[] salt) {
        _salt = salt;
    }
    public void set_hashed(String hashedPassword) {
        _hashed = hashedPassword;
    }

    public String get_username() {
        return _username;
    }
    public byte[] get_salt() {
        return _salt;
    }
    public String get_hashed() {
        return _hashed;
    }
}
