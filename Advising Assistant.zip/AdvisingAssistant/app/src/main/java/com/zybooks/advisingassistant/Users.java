package com.zybooks.advisingassistant;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;
import android.util.Log;

public class Users extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 4;
    private static final String DATABASE_NAME = "users";

    public Users(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    static final class UserTable implements BaseColumns {
        static final String TABLE = "allUsers";
        static final String USERNAME = "usernames";
        static final String PASSWORD = "passwordHashed";
        //static final String SALT = "salt";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = ("CREATE TABLE " + UserTable.TABLE + "(" + UserTable._ID  + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                UserTable.USERNAME + " TEXT," + UserTable.PASSWORD + " TEXT ) ");
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS allUsers");
        onCreate(db);
    }
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }

    /* The add method will add the username and password ( and salt when works) to the table by the insert command. */
    public void add(String username, String password) {
        Log.d("add in Users", "method entered");
        SQLiteDatabase db = this.getWritableDatabase();
        Log.d("database opened", "database opened");

        ContentValues values = new ContentValues();
        values.put(UserTable.USERNAME, username);
        values.put(UserTable.PASSWORD, password);
        //values.put("salt", salt);

        Long result = db.insert(UserTable.TABLE, null, values);
        db.close();

        Log.d("db", "db added");
    }
    /* This is query will verify if the username given from the user is existing in the table. */
    public Boolean verifyUsername(String username) {
        String selectQuery = "SELECT EXISTS (SELECT 1 FROM " + UserTable.TABLE + " WHERE " + UserTable.USERNAME + " = ?) ";
        String[] args = { String.valueOf(username) };
        boolean exists = false;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor =  db.rawQuery(selectQuery, args);

        if (cursor.moveToFirst()) {
            exists = (cursor.getInt(0) == 1);
        }
        cursor.close();
        db.close();

        return exists;
    }

    // This will use the username to call for the hashed password that was saved for the given username.
    public String getStoredPassword(String username) {
        Log.d("getStoredPassword", "entered method");
        String storedPassword = null;
        String selectQuery = " SELECT " + UserTable.PASSWORD + " FROM " + UserTable.TABLE + " WHERE " + UserTable.USERNAME + " = ?";
        String[] selectionArgs = { String.valueOf(username)};

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor =  db.rawQuery(selectQuery, selectionArgs);

        if (cursor.moveToFirst()) {
            int colIndex = cursor.getColumnIndex(UserTable.PASSWORD);
            if (colIndex != -1) {
                storedPassword = cursor.getString(colIndex);
            }
        }
        cursor.close();
        db.close();

        return storedPassword;
    }
    /* This will allow us to gain access to the stored salt. If it was working properly
    *
    * The byte[] we retrieve changes when it is called. We need to fix this issue before reactivating this method.*/
    /*public byte[] getStoredByte(String username) {
        byte[] savedSalt = null;
        String selectQuery = " SELECT salt FROM " + UserTable.TABLE + " WHERE " + UserTable.USERNAME + " = ?";
        String[] selectionArgs = { String.valueOf(username)};

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor =  db.rawQuery(selectQuery, selectionArgs);

        if (cursor != null && cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndex("salt");
            savedSalt = cursor.getBlob(columnIndex);
            Log.d("getByte", "byte " + savedSalt);

        }
        if (cursor != null) {
            cursor.close();
        }
        db.close();
        return savedSalt;
    }*/
}

