package com.zybooks.advisingassistant;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class ListCourseNames extends AppCompatActivity {

    BinaryTreeClass binaryTreeClass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.list_course_names);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextView display = findViewById(R.id.listView);
        display.setText("Courses Listed Below\n");

        ArrayList<Course> courseList = binaryTreeClass.getCourseList();

        if (courseList.isEmpty()) {
            display.append("no courses");
        } else {
            for (int i =0; i < courseList.size(); i++) {
                Log.d("check list", "in list for statement");
                display.append(courseList.get(i).getCourseId() + ": "+ courseList.get(i).getName() + "\n");
            }
        }


        // This button returns from current page to MainActivity class
        Button backButton = findViewById(R.id.back);
        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(ListCourseNames.this.getBaseContext(), MainActivity.class);
            ListCourseNames.this.startActivity(intent);
        });

    }
    protected void onPause(){
        super.onPause();
    }
    protected void onResume() {
        super.onResume();
    }

}