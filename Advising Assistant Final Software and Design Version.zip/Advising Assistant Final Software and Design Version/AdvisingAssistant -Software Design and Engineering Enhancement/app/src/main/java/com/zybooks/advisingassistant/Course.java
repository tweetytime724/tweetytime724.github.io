package com.zybooks.advisingassistant;


import android.content.ContentValues;
import android.database.Cursor;

// This is a public class to hold special information for the courses.
public class Course {
    String _courseId;
    String _name;
    String _preReq;
    int _iD;

    // constructors to add information to the class Course
    public void set_courseId(String id) {
        _courseId = id;
    }
    public void set_name(String name) { _name = name; }
    public void set_preReq(String req) {
        _preReq = req;
    }
    public void setiD(int num) { _iD = num; }

    // accessors for easy call back
    public String getCourseId() {
        return _courseId;
    }
    public String getName() {
        return _name;
    }
    public String get_preReq() {
        return _preReq;
    }
    public int getiD() { return _iD; }

    public ContentValues getContentValuesToAdd() {
        ContentValues values = new ContentValues();
        values.put("id", getCourseId());
        values.put("name", getName());
        values.put("preR", get_preReq());
        return values;
    }

    public void parse(Cursor cursor) {
        set_courseId(cursor.getString(0));
        set_name(cursor.getString(1));
        set_preReq(cursor.getString(2));
    }
}




