package com.zybooks.advisingassistant;

import android.util.Log;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class BinaryTreeClass {
    /* The Node class is for use of the Binary Tree class. The Binary Tree class is a special way to store
     * data for easy retrieval. It will search for the best place to store the information based by the Id.
     * When Displaying the whole list of class inputted, it should display in alpha-numerical order.
     *
     * The addToTree method would check the root to see if it is null then if not it will continue to add
     * a node to the tree. */
    static class Node {
        Course course;
        Node left = null;
        Node right = null;

        Node(Course someCourse) {
            course = someCourse;
        }

    }
    static Node root;
    static ArrayList<Course> single = new ArrayList<>();
    static ArrayList<Course> list = new ArrayList<>();
    Node savedRoot;

    public void addRoot(Course course) {
        root = new Node(course);
    }

    public Node getRoot() {
        return root;
    }

    public void addToTree(Course course) {
        if (root == null) {
            addRoot(course);
        }
        else {
            savedRoot = getRoot();
            addNode(savedRoot, course);
        }
    }
    public void addNode(Node node, Course course) {
        if (node.course._courseId.compareTo(course._courseId) > 0) {
            if (node.left == null) {
                node.left = new Node(course);
            }
            else{
                addNode(node.left, course);
            }
        }
        else {
            if (node.right == null) {
                node.right = new Node(course);
            }
            else {
                addNode(node.right, course);

            }
        }
    }

    public static void displayTree() {
        inOrder(root);
    }
    public static void inOrder(Node node) {

        if (node != null) {
            inOrder(node.left);
            list.add(node.course);

            inOrder(node.right);
        }
        else {
            //This is for testing.
            Log.d("isnull", "the root is null");
        }
    }

    /* This method will call the displayTree() method which will grab the root node to be used in
    * the inOrder method. That is where the system will go through the tree to get all the courses
    * in alpha-numeric order - left to right, bottom to top.*/
    public static ArrayList<Course> getCourseList() {
        displayTree();
        return list;
    }
    /* This method will display the course being requested. It will check every node in the correct
    * side of the tree until it finds the one it needs.*/
    public static ArrayList<Course> getOneCourse(String id) {
        Node current = root;

        while (current != null) {
            if (current.course._courseId.compareTo(id) == 0) {
                single.add(current.course);
                return single;
            }
            else if (current.course._courseId.compareTo(id) < 0) {
                current = current.right;
            } else {
                current = current.left;
            }
        }
        return null;
    }
}

