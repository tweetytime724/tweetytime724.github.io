package com.zybooks.advisingassistant;

import static android.view.View.VISIBLE;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class AddCourse extends AppCompatActivity {

    BinaryTreeClass binaryTreeclass = new BinaryTreeClass();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_course);

        TextView error = findViewById(R.id.errorsDisplay);

        // This button returns from current page to MainActivity class
        Button backButton = findViewById(R.id.back);
        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(AddCourse.this.getBaseContext(), MainActivity.class);
            AddCourse.this.startActivity(intent);
        });

        // variables for taking in the course information that was entered.
        EditText addId = findViewById(R.id.addCourseID);
        EditText addName = findViewById(R.id.addCourseName);
        EditText addPreReq = findViewById(R.id.addPreReq);

        /* This button will create variables for the 3 input text. If there is a null variable it will
        * spit out an error in the edit text box at the bottom of the page.
        *
        * It will store the data in a temporary object to be added to the tree. It will then clear
        * the lines for another course to be added.  */
        @NonNull
        Button addID = findViewById(R.id.addCourseButton);
        addID.setOnClickListener(v -> {
            Course course = new Course();

            String id = addId.getText().toString();
            Log.d("id", id);
            String name = addName.getText().toString();
            Log.d("name", name);
            String req = addPreReq.getText().toString();
            Log.d("req", req);

            course.set_courseId(id);
            Log.d("Input", "ID GOOD");
            course.set_name(name);
            Log.d("Input", "NAME GOOD");
            course.set_preReq(req);
            Log.d("Input", "PREREQ GOOD");

            if (course != null) {
                binaryTreeclass.addToTree(course);
                addId.setText("");
                addName.setText("");
                addPreReq.setText("");
            }
            else {
                error.setVisibility(VISIBLE);
            }

        });
    }
    protected void onPause(){
        super.onPause();
    }
    protected void onResume() {
        super.onResume();
    }

}
